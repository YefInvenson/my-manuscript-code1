#' This is some description of this function.
#' @title tukeytest2
#' 
#' @description There are some functions for tukey test
#' 
#' @details you can use this function to add significant markers for your data 
#' 
#' @param a a is the data you want to do tukey-test and add significant markers 
#' @param n1 n1 is the column number for grouping (Classification 1)
#' @param n2 n2 is the column number for grouping (Classification 2)
#' @param n  n  is the column number you want to add significant markers
#' 
#' @return a dataframe
#' @export 
f_tukey2<-function(n1,n2,n,a){
  b<-f_tukey1(n1,n,a)
  c<-f_ave(n1,n,a)
  dim_c=dim(c)[1]
  dd<-data.frame()
  for(i in 1:dim_c){
    d<-f_sel(n1,i,a)
    d<-f_tukey1(n2,n,d)
    d[,2:4]=d[,1:3]
    d[1:dim(d)[1],1]=c[i,1]
    if(i==1){
      dd=d
    }else{
      dd<-rbind(dd,d)
    }
  }
  for(i in 1:dim(b)[1]){
    for(j in 1:dim(dd)[1]){
      if(dd[j,1]==b[i,1]){
        dd[j,5]=b[i,3]
      }
    }
  }
  ddd<-dd[,5]
  dd[,5]=dd[,4]
  dd[,4]=ddd
  colnames(dd)<-c("V1","V2","mean","sig_mark1","sig_mark2")
  return(dd)
}
#' @title tukeytest1
#' 
#' @description There are some functions for tukey test
#' 
#' @details you can use this function to add significant markers for your data 
#' 
#' @param a a is the data you want to do tukey test and add significant markers 
#' @param n1 n1 is the column number for grouping (Classification)
#' @param n  n  is the column number you want to add significant markers
#' 
#' @return a dataframe
#' @export 
f_tukey1<-function(n1,n,a){
  b <- data.frame(
    vol1 = a[, n1],
    value = a[, n]
  )
  c<-f_seq(1,b)
  aov_result <- aov(c$value~c$vol1,c)
  p_value<-summary(aov_result)[[1]]$`Pr(>F)`[1]
  c=f_ave(1,2,c)
  c=f_seq(2,c)
  z=f_HSD(n1,n,a)
  #obtain a-z,A-Z
  L1<- intToUtf8(seq(utf8ToInt('a'), utf8ToInt('z')), multiple = TRUE)
  L2<- intToUtf8(seq(utf8ToInt('A'), utf8ToInt('Z')), multiple = TRUE)
  dim_c=dim(c)[2]
  if(p_value>=0.05){
    print(c("数据关于第",n1,"列没有显著差异"))
    c[1:dim(c)[1],dim_c+1]="n"
  }else if(p_value<0.05&&p_value>=0.01){
    print(c("数据关于第",n1,"列有显著差异，p<0.05"))
    c[1, dim_c+1]=L1[1]
    k=1
    #==
    midd=c[1,2]
    for(i in 2:dim(c)[1]){
      if((c[i,2]-midd)<z[1]){
        c[i, dim_c+1]=c[i-1, dim_c+1]
      }else{
        k=k+1
        midd=c[i,2]
        c[i, dim_c+1]=L1[k]
      }
    }
  }else if(p_value<0.01){
    print(c("数据关于第",n1,"列有高显著差异，p<0.01"))
    c[1, dim_c+1]=L2[1]
    k=1
    #==
    midd=c[1,2]
    for(i in 2:dim(c)[1]){
      if((c[i,2]-c[i-1,2])<z[2]){
        c[i,dim_c+1]=c[i-1, dim_c+1]
      }else{
        k=k+1
        midd=c[i,2]
        c[i,dim_c+1]=L2[k]
      }
    }
  }
  c=f_seq(1,c)
  return(c)
}

#' @title sequence
#' 
#' @description order the data
#' 
#' @details you can use this function to order the data 
#' 
#' @param a a is the data you want to order it's sequence
#' @param n  n  is the column number you want to order it's sequence
#' 
#' @return a dataframe
#' @export 
f_seq<-function(n,a){
  for(i in 1:dim(a)[1]){
    for(j in i:dim(a)[1]){
      if(a[i,n]>a[j,n]){
        c=a[i,]
        a[i,]=a[j,]
        a[j,]=c
      }
    }
  }
  return(a)
}

#' @title meanvalue
#' 
#' @description calculate the average
#' 
#' @details you can use this function to calculate the average
#' @param a a is the data you want to calculate average values
#' @param n0  n0  is the column number for classification
#' @param n1  n1  is the column number you want to calculate average values
#' 
#' @return a dataframe
#' @export 
f_ave<-function(n0,n1,a){
  a=f_seq(n0,a)
  b=data.frame()
  b[1,1]=a[1,n0]
  b[1,2]=a[1,n1]
  k=1
  nn=numeric()
  nn[1]=0
  for(i in 2:dim(a)[1]){
    if(a[i,n0]==a[i-1,n0]){
      b[k,1]=a[i,n0]
      b[k,2]=b[k,2]+a[i,n1]
    }else{
      k=k+1
      b[k,1]=a[i,n0]
      b[k,2]=a[i,n1]
    }
    nn[k+1]=i
  }
  for(i in 1:dim(b)[1]){
    b[i,2]=b[i,2]/(nn[i+1]-nn[i])
  }
  return(b)
}
  

#' @title HSDvalue
#' 
#' @description calculate the HSD-value
#' 
#' @details you can use this function to calculate the HSD-value
#' @param a a is the data you want to calculate HSD value
#' @param n0 n0 is the column number for grouping (Classification)
#' @param n1 n1  is the column number you want to calculate HSD value
#' 
#' @importFrom stats aov
#' @importFrom stats qtukey
#' 
#' @return a dataframe
#' @export 
f_HSD<-function(n0,n1,a){
  b<-f_seq(n0,a)
  d<-f_ave(n0,n1,a)
  c=data.frame(b)
  for(i in 1:dim(b)[1]){
    for(j in 1:dim(d)[1]){
      if(b[i,n0]==d[j,1]){
        c[i,n1]=(b[i,n1]-d[j,2])^2
      }
    }
  }
  SSE=sum(c[1:dim(c)[1],n1])
  nn=dim(a)[1]
  kk=dim(d)[1]
  df=nn-kk
  MSE=SSE/df
  q1=qtukey(0.95,kk,df)
  q2=qtukey(0.99,kk,df)
  HSD_95=q1*sqrt(MSE/nn)
  HSD_99=q2*sqrt(MSE/nn)
  HSD<-c(HSD_95,HSD_99)
  return(HSD)
}


#' @title separate
#' 
#' @description separate some data which has a symbol different with others
#' 
#' @details you can use this function to separate some data,
#'           which has a symbol different with others
#' @param a a is the data you want to separate part from it
#' @param n n is the column number for grouping (Classification)
#' @param m m is the column number you want to separate part from it
#' 
#' @return a dataframe
#' @export
f_sel<-function(n,m,a){
  a<-f_seq(n,a)
  for(i in 1:dim(a)[1]){
    if(i==1){
      kk<-a[1,n]
    }else{
      if(a[i,n]!=a[i-1,n]){
        kk<-rbind(kk,a[i,n])
      }
    }
  }
  
  d<-data.frame()
  k=1
  j=1
  for(i in 1:dim(a)[1]){
    if(a[i,n]==kk[m]){
      d[j,1:dim(a)[2]]=a[i,1:dim(a)[2]]
      j=j+1
    }
  }
  return(d)
}

